from django.apps import AppConfig


class CostManagementConfig(AppConfig):
    name = 'cost_management'
